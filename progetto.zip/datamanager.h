#ifndef DATAMANAGER_H
#define DATAMANAGER_H

#include <QString>
#include <vector>
#include <map>
#include <set>

struct Studente {
    int matricola;
    QString cognome;
    QString nome;
};

struct Materia {
    QString codice;
    QString descrizione;
};

struct Corso {
    QString codice;
    QString descrizione;
};

struct RigaCSV {
    Corso corso;
    Materia materia;
    Studente studente;
};

class DataManager
{
public:
    DataManager();
    bool loadData();
    bool saveData();

    QString searchStudentByID(int matricola) const;
    QString searchStudentBySurname(const QString &cognome) const;
    QString getStudentsByCourse(const QString &courseCode) const;
    QString getCourseDetails(const QString &courseCode) const;
    QString countStudentsPerCourse() const;
    QString countSubjectsPerCourse() const;
    QString searchSubjects(const QString &searchTerm) const;
    QString addStudent(int matricola, const QString &cognome, const QString &nome, const QString &subjectCode);

private:
    std::vector<RigaCSV> dati;

    QString toLower(const QString &s) const;
    bool isNumber(const QString &s) const;
    QString formatStudent(const Studente &s) const;
};
#endif // DATAMANAGER_H
