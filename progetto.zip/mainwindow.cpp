#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QFileDialog>
const QString filename="corsi_studenti.csv";

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Managment studenti e corsi università");

    // Load data
    if (!dataManager.loadData()) {
        QMessageBox::warning(this, "Attenzione", "File csv non trovato / non apribile");
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::displayResults(const QString &results)
{
    ui->resultsTextEdit->setPlainText(results);
}

void MainWindow::on_searchByIDButton_clicked()
{
    bool ok;
    int matricola = ui->idLineEdit->text().toInt(&ok);
    if (!ok) {
        QMessageBox::warning(this, "Errore", "Inserisci un numero di matricola valido");
        return;
    }

    QString results = dataManager.searchStudentByID(matricola);
    displayResults(results);
}

void MainWindow::on_searchBySurnameButton_clicked()
{
    QString cognome = ui->surnameLineEdit->text();
    if (cognome.isEmpty()) {
        QMessageBox::warning(this, "Errore", "Inserisci un cognome");
        return;
    }

    QString results = dataManager.searchStudentBySurname(cognome);
    displayResults(results);
}

void MainWindow::on_studentsByCourseButton_clicked()
{
    QString codice = ui->courseCodeLineEdit->text();
    if (codice.isEmpty()) {
        QMessageBox::warning(this, "Errore", "Inserisci un codice del corso");
        return;
    }

    QString results = dataManager.getStudentsByCourse(codice);
    displayResults(results);
}

void MainWindow::on_courseDetailsButton_clicked()
{
    QString codice = ui->courseDetailsLineEdit->text();
    if (codice.isEmpty()) {
        QMessageBox::warning(this, "Errore", "Inserisci un codice del corso");
        return;
    }

    QString results = dataManager.getCourseDetails(codice);
    displayResults(results);
}

void MainWindow::on_studentsCountButton_clicked()
{
    QString results = dataManager.countStudentsPerCourse();
    displayResults(results);
}

void MainWindow::on_subjectsCountButton_clicked()
{
    QString results = dataManager.countSubjectsPerCourse();
    displayResults(results);
}

void MainWindow::on_searchSubjectsButton_clicked()
{
    QString searchTerm = ui->subjectSearchLineEdit->text();
    if (searchTerm.isEmpty()) {
        QMessageBox::warning(this, "Errore", "Inserisci un termine della ricerca");
        return;
    }

    QString results = dataManager.searchSubjects(searchTerm);
    displayResults(results);
}

void MainWindow::on_addStudentButton_clicked()
{
    bool ok;
    int matricola = ui->newStudentIDLineEdit->text().toInt(&ok);
    if (!ok) {
        QMessageBox::warning(this, "Errore", "Inserisci un numero di matricola valida");
        return;
    }

    QString cognome = ui->newStudentSurnameLineEdit->text();
    QString nome = ui->newStudentNameLineEdit->text();
    QString subjectCode = ui->newStudentSubjectLineEdit->text();

    if (cognome.isEmpty() || nome.isEmpty() || subjectCode.isEmpty()) {
        QMessageBox::warning(this, "Errore", "Inserisci tutti i valori");
        return;
    }

    QString result = dataManager.addStudent(matricola, cognome, nome, subjectCode);
    QMessageBox::information(this, "Risultato", result);
}

void MainWindow::on_saveButton_clicked()
{
    if (dataManager.saveData()) {
        QMessageBox::information(this, "Successo", "Dati salvati");
    } else {
        QMessageBox::warning(this, "Errore", "Non è possibile salvare i dati");
    }
}
