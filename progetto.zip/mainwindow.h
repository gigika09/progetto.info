#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "datamanager.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_searchByIDButton_clicked();
    void on_searchBySurnameButton_clicked();
    void on_studentsByCourseButton_clicked();
    void on_courseDetailsButton_clicked();
    void on_studentsCountButton_clicked();
    void on_subjectsCountButton_clicked();
    void on_searchSubjectsButton_clicked();
    void on_addStudentButton_clicked();
    void on_saveButton_clicked();

private:
    Ui::MainWindow *ui;
    DataManager dataManager;
    void displayResults(const QString &results);
};
#endif // MAINWINDOW_H
