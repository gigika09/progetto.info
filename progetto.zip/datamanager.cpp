
#include "datamanager.h"
#include <QFile>
#include <QTextStream>
#include <QStringList>
#include <QDebug>
const QString filename= "corsi_studenti.csv";

DataManager::DataManager()
{
}

QString DataManager::toLower(const QString &s) const
{
    return s.toLower();
}

bool DataManager::isNumber(const QString &s) const
{
    bool ok;
    s.toInt(&ok);
    return ok;
}

QString DataManager::formatStudent(const Studente &s) const
{
    return QString("%1 %2 (%3)").arg(s.cognome).arg(s.nome).arg(s.matricola);
}

bool DataManager::loadData()
{
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return false;
    }

    QTextStream in(&file);
    dati.clear();

    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(',');

        if (fields.size() < 7) continue;

        RigaCSV r;
        r.corso.codice = fields[0];
        r.corso.descrizione = fields[1];
        r.materia.codice = fields[2];
        r.materia.descrizione = fields[3];

        bool ok;
        r.studente.matricola = fields[4].toInt(&ok);
        if (!ok) continue;

        r.studente.cognome = fields[5];
        r.studente.nome = fields[6];

        dati.push_back(r);
    }

    file.close();
    return true;
}

bool DataManager::saveData()
{
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return false;
    }

    QTextStream out(&file);

    for (const auto& r : dati) {
        out << r.corso.codice << "," << r.corso.descrizione << ","
            << r.materia.codice << "," << r.materia.descrizione << ","
            << r.studente.matricola << "," << r.studente.cognome << "," << r.studente.nome << "\n";
    }

    file.close();
    return true;
}

QString DataManager::searchStudentByID(int matricola) const
{
    QString result;
    bool found = false;

    for (const auto& r : dati) {
        if (r.studente.matricola == matricola) {
            result += QString("%1 - %2 | Materia: %3 - %4\n")
                .arg(r.corso.codice)
                .arg(r.corso.descrizione)
                .arg(r.materia.codice)
                .arg(r.materia.descrizione);
            found = true;
        }
    }

    if (!found) {
        result = "Nesun corso trovato con questo numero di matricola.\n";
    }

    return result;
}

QString DataManager::searchStudentBySurname(const QString &cognome) const
{
    QString result;
    bool found = false;
    QString searchSurname = toLower(cognome);

    for (const auto& r : dati) {
        if (toLower(r.studente.cognome) == searchSurname) {
            result += QString("%1 %2 %3 - Corso: %4 - %5 | Materia: %6 - %7\n")
            .arg(r.studente.matricola)
                .arg(r.studente.nome)
                .arg(r.studente.cognome)
                .arg(r.corso.codice)
                .arg(r.corso.descrizione)
                .arg(r.materia.codice)
                .arg(r.materia.descrizione);
            found = true;
        }
    }

    if (!found) {
        result = "Nessun studente trovato con questo cognome.\n";
    }

    return result;
}

QString DataManager::getStudentsByCourse(const QString &courseCode) const
{
    QString result;
    bool found = false;
    QString searchCode = toLower(courseCode);
    std::set<int> seenStudents;
    QString originalCode;

    for (const auto& r : dati) {
        if (toLower(r.corso.codice) == searchCode) {
            if (!found) {
                originalCode = r.corso.codice;
                result += QString("Studenti del corso %1:\n").arg(originalCode);
                found = true;
            }

            if (seenStudents.insert(r.studente.matricola).second) {
                result += QString(" - %1: %2 %3\n")
                .arg(r.studente.matricola)
                    .arg(r.studente.cognome)
                    .arg(r.studente.nome);
            }
        }
    }

    if (!found) {
        result = "Codice corso non trovato.\n";
    } else {
        result += QString("Studenti trovati: %1\n").arg(seenStudents.size());
    }

    return result;
}

QString DataManager::getCourseDetails(const QString &courseCode) const
{
    QString result;
    bool found = false;
    QString searchCode = toLower(courseCode);
    std::map<QString, std::set<QString>> subjectStudents; // subject -> students

    for (const auto& r : dati) {
        if (toLower(r.corso.codice) == searchCode) {
            found = true;
            QString subjectKey = r.materia.codice + " - " + r.materia.descrizione;
            QString studentInfo = formatStudent(r.studente);
            subjectStudents[subjectKey].insert(studentInfo);
        }
    }

    if (!found) {
        result = "Codice corso non trovato.\n";
    } else {
        result += QString("Dettagli per corso %1:\n").arg(courseCode);
        for (const auto& [subject, students] : subjectStudents) {
            result += QString("\nMateria: %1\n").arg(subject);
            result += QString("Studenti (%1):\n").arg(students.size());
            for (const auto& student : students) {
                result += " - " + student + "\n";
            }
        }
    }

    return result;
}

QString DataManager::countStudentsPerCourse() const
{
    QString result;
    std::map<QString, std::set<int>> courseStudents;

    for (const auto& r : dati) {
        courseStudents[r.corso.codice].insert(r.studente.matricola);
    }

    for (const auto& [course, students] : courseStudents) {
        result += QString("Corso %1: %2 studenti\n").arg(course).arg(students.size());
    }

    if (result.isEmpty()) {
        result = "Nessun dato disponibile.\n";
    }

    return result;
}

QString DataManager::countSubjectsPerCourse() const
{
    QString result;
    std::map<QString, std::set<QString>> courseSubjects;

    for (const auto& r : dati) {
        courseSubjects[r.corso.codice].insert(r.materia.codice);
    }

    for (const auto& [course, subjects] : courseSubjects) {
        result += QString("Corso %1: %2 materie\n").arg(course).arg(subjects.size());
    }

    if (result.isEmpty()) {
        result = "Nessun dato disponibile.\n";
    }

    return result;
}

QString DataManager::searchSubjects(const QString &searchTerm) const
{
    QString result;
    if (searchTerm.isEmpty()) {
        return "Nessun valore di ricerca trovato.\n";
    }

    QString searchTermLower = toLower(searchTerm);
    std::map<QString, std::pair<QString, std::set<QString>>> results; // subject code -> (description, students)

    for (const auto& r : dati) {
        QString codeLower = toLower(r.materia.codice);
        QString descLower = toLower(r.materia.descrizione);

        if (codeLower.contains(searchTermLower) || descLower.contains(searchTermLower)) {
            if (results.find(r.materia.codice) == results.end()) {
                results[r.materia.codice].first = r.materia.descrizione;
            }
            results[r.materia.codice].second.insert(formatStudent(r.studente));
        }
    }

    if (results.empty()) {
        result = QString("No subjects found containing '%1'\n").arg(searchTerm);
    } else {
        for (const auto& [code, info] : results) {
            const auto& [desc, students] = info;
            result += QString("\nMateria: %1 - %2\n").arg(code).arg(desc);
            result += QString("Studenti iscritti (%1):\n").arg(students.size());
            for (const auto& student : students) {
                result += "  " + student + "\n";
            }
        }
    }

    return result;
}

/*QString DataManager::addStudent(int matricola, const QString &cognome, const QString &nome, const QString &subjectCode)
{
    bool subjectFound = false;
    QString subjectCodeLower = toLower(subjectCode);

    for (const auto& r : dati) {
        if (toLower(r.materia.codice) == subjectCodeLower) {
            RigaCSV newRecord = r;
            newRecord.studente = {matricola, cognome, nome};
            dati.push_back(newRecord);
            subjectFound = true;
            return QString("Studente aggiunto al corso %1").arg(r.corso.codice);
        }
    }

    return "Materia non trovata, studente non inserito";
}*/
QString DataManager::addStudent(int matricola, const QString &cognome, const QString &nome, const QString &subjectCode)
{
    qDebug() << "addStudent chiamato con:" << matricola << cognome << nome << subjectCode;

    QString subjectCodeLower = toLower(subjectCode);

    for (const auto& r : dati) {
        if (toLower(r.materia.codice) == subjectCodeLower) {
            RigaCSV newRecord = r;
            newRecord.studente = {matricola, cognome, nome};
            dati.push_back(newRecord);
            qDebug() << "Studente aggiunto al corso:" << r.corso.codice;
            return QString("Studente aggiunto al corso %1").arg(r.corso.codice);
        }
    }

    return "Materia non trovata, studente non inserito";
}


